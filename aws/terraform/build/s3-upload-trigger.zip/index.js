"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const sqs = new client_sqs_1.SQSClient({});
const queueUrl = process.env.UPLOAD_QUEUE_URL || '';
async function handler(event) {
    for (const record of event.Records) {
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
        const bucket = record.s3.bucket.name;
        if (!queueUrl)
            continue;
        await sqs.send(new client_sqs_1.SendMessageCommand({
            QueueUrl: queueUrl,
            MessageBody: JSON.stringify({
                type: 's3-upload',
                bucket,
                key,
                eventTime: record.eventTime,
            }),
        }));
    }
}
