"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const uuid_1 = require("uuid");
const doc = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({}));
const tableName = process.env.ANALYTICS_TABLE || 'superplane-analytics';
async function handler(event) {
    for (const record of event.Records) {
        let payload = {};
        try {
            payload = JSON.parse(record.Sns.Message);
        }
        catch {
            payload = { raw: record.Sns.Message };
        }
        await doc.send(new lib_dynamodb_1.PutCommand({
            TableName: tableName,
            Item: {
                id: (0, uuid_1.v4)(),
                type: String(payload.type || 'sns-event'),
                offerId: payload.offerId,
                metadata: payload,
                source: 'lambda-sns-to-analytics',
                createdAt: new Date().toISOString(),
            },
        }));
    }
}
